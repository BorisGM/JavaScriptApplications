import page from '../node_modules/page/page.mjs';

export const redirect = (path) => page.redirect(path);