import { start } from './booksView.js';

document.getElementById('loadBooks').addEventListener('click', start);