import { create } from '../controllers/team.js';
import { html } from '../node_modules/lit-html/lit-html.js';
import { footerView } from './footerView.js';
import { navigationView } from './navigationView.js';

export const createView = (ctx) => html`
    ${navigationView(ctx)}
    <main>
        <section id="create">
            <article class="narrow">
                <header class="pad-med">
                    <h1>New Team</h1>
                </header>
                <form id="create-form" class="main-form pad-large" @submit=${(e)=> { create(e, ctx) }}>
                    <div class="error">Error message.</div>
                    <label>Team name: <input type="text" name="name"></label>
                    <label>Logo URL: <input type="text" name="logoUrl"></label>
                    <label>Description: <textarea name="description"></textarea></label>
                    <input class="action cta" type="submit" value="Create Team">
                </form>
            </article>
        </section>
    </main>
    ${footerView()}`;