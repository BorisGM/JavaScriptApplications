import { html } from '../node_modules/lit-html/lit-html.js';

export const footerView = () => html`
    <footer id="footer">
        SoftUni &copy; 2014-2021
    </footer>`;